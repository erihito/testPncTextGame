﻿namespace imwp
{
    partial class form_main
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.main_textbox = new System.Windows.Forms.RichTextBox();
            this.main_gachabt = new System.Windows.Forms.Button();
            this.main_statbt = new System.Windows.Forms.Button();
            this.main_textin = new System.Windows.Forms.TextBox();
            this.main_startbt = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // main_textbox
            // 
            this.main_textbox.Location = new System.Drawing.Point(12, 13);
            this.main_textbox.Name = "main_textbox";
            this.main_textbox.ReadOnly = true;
            this.main_textbox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.main_textbox.Size = new System.Drawing.Size(362, 465);
            this.main_textbox.TabIndex = 2;
            this.main_textbox.Text = "";
            this.main_textbox.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.form_main_PreviewKeyDown);
            // 
            // main_gachabt
            // 
            this.main_gachabt.Enabled = false;
            this.main_gachabt.Location = new System.Drawing.Point(380, 469);
            this.main_gachabt.Name = "main_gachabt";
            this.main_gachabt.Size = new System.Drawing.Size(81, 36);
            this.main_gachabt.TabIndex = 3;
            this.main_gachabt.Text = "뽑기";
            this.main_gachabt.UseVisualStyleBackColor = true;
            this.main_gachabt.Click += new System.EventHandler(this.main_gachabt_Click);
            this.main_gachabt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.form_main_PreviewKeyDown);
            // 
            // main_statbt
            // 
            this.main_statbt.Enabled = false;
            this.main_statbt.Location = new System.Drawing.Point(380, 428);
            this.main_statbt.Name = "main_statbt";
            this.main_statbt.Size = new System.Drawing.Size(81, 35);
            this.main_statbt.TabIndex = 4;
            this.main_statbt.Text = "상태출력";
            this.main_statbt.UseVisualStyleBackColor = true;
            this.main_statbt.Click += new System.EventHandler(this.main_statbt_Click);
            this.main_statbt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.form_main_PreviewKeyDown);
            // 
            // main_textin
            // 
            this.main_textin.Enabled = false;
            this.main_textin.Location = new System.Drawing.Point(12, 484);
            this.main_textin.Name = "main_textin";
            this.main_textin.Size = new System.Drawing.Size(362, 21);
            this.main_textin.TabIndex = 5;
            this.main_textin.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.form_main_PreviewKeyDown);
            // 
            // main_startbt
            // 
            this.main_startbt.Location = new System.Drawing.Point(477, 13);
            this.main_startbt.Name = "main_startbt";
            this.main_startbt.Size = new System.Drawing.Size(81, 35);
            this.main_startbt.TabIndex = 6;
            this.main_startbt.Text = "시작";
            this.main_startbt.UseVisualStyleBackColor = true;
            this.main_startbt.Click += new System.EventHandler(this.main_startbt_Click);
            this.main_startbt.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.form_main_PreviewKeyDown);
            // 
            // form_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 517);
            this.Controls.Add(this.main_startbt);
            this.Controls.Add(this.main_textin);
            this.Controls.Add(this.main_statbt);
            this.Controls.Add(this.main_gachabt);
            this.Controls.Add(this.main_textbox);
            this.KeyPreview = true;
            this.Name = "form_main";
            this.Text = "Test";
            this.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.form_main_PreviewKeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RichTextBox main_textbox;
        private System.Windows.Forms.Button main_gachabt;
        private System.Windows.Forms.Button main_statbt;
        private System.Windows.Forms.TextBox main_textin;
        private System.Windows.Forms.Button main_startbt;
    }
}

