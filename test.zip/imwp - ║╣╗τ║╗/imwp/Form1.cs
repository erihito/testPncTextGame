﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace imwp
{ 
    public partial class form_main : Form
    {
        string textmsg;
        List<string> savetxt = new List<string>();

        string[,] gachapool = {
            { "0", "테스트0", "1"},
            { "1", "테스트1", "1"},
            { "2", "테스트2", "1"},
            { "3", "테스트3", "1"},
            { "4", "테스트4", "1"},
            { "5", "테스트5", "1"}
        };

        public form_main()
        {
            InitializeComponent();
        }
        protected void form_main_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            //key_fnc(e);
        }
        public void key_fnc(PreviewKeyDownEventArgs e)
        {
            //switch (e.KeyCode)
            //{
            //    case Keys.D1:
            //        main_textbox.AppendText("key : " + 1 + "\r\n");
            //        break;
            //}
            if (e != null)
            {
                main_textbox.AppendText(e.KeyCode + "\r\n");
                main_textbox.ScrollToCaret();
            }
            if (e.KeyCode == Keys.Enter)
            {
                if (main_textin.Enabled == false)
                {
                    main_textin.Enabled = true;
                    main_textin.Focus();
                }
                else if (main_textin.Enabled == true && main_textin.Text.Length != 0)
                {
                    textmsg = main_textin.Text.ToString();
                    main_textbox.AppendText(textmsg + "\r\n");
                    main_textbox.ScrollToCaret();

                    //input function
                    command_fnc(textmsg);

                    main_textin.Enabled = false;
                    main_textin.Clear();
                }
                else if (main_textin.Enabled == true && main_textin.Text.Length == 0)
                {
                    main_textin.Enabled = false;
                    //main_textbox.AppendText("-" + "\r\n");
                    //main_textbox.ScrollToCaret();
                }
            }
        }

        public void command_fnc(string text)
        {
            string[] command = text.Split(' ');
            if (command[0] == "do")
            {
                //foreach (string s in command)
                //{
                //    main_textbox.AppendText(s+"\r\n");
                //}
                try
                {
                    switch (command[1])
                    {
                        case "list":
                            main_textbox.AppendText("-test : print TEST!" + "\r\n");
                            main_textbox.AppendText("-list : print command list" + "\r\n");
                            main_textbox.AppendText("-clear : clear txt box" + "\r\n");
                            main_textbox.AppendText("-exit : program exit" + "\r\n");
                            main_textbox.ScrollToCaret();
                            break;
                        case "test":
                            main_textbox.AppendText("-TEST!" + "\r\n");
                            main_textbox.ScrollToCaret();
                            break;
                        case "clear":
                            main_textbox.Clear();
                            break;
                        case "echo":
                            main_textbox.AppendText("-ECHO : ");
                            for(int i = 2; i < command.Length; i++)
                            {
                                main_textbox.AppendText(command[i]+ " ");
                            }
                            main_textbox.AppendText("\r\n");
                            main_textbox.ScrollToCaret();
                            break;
                        case "exit":
                            Application.Exit();
                            break;
                        default:
                            main_textbox.AppendText("-Invalid command" + "\r\n");
                            main_textbox.ScrollToCaret();
                            break;

                    }
                }
                catch
                {
                    main_textbox.AppendText("-Use \"do (command)\"" + "\r\n");
                    main_textbox.ScrollToCaret();
                }
            }
        }

        private void main_gachabt_Click(object sender, EventArgs e)
        {
            int gc;
            if (savetxt.Count < 3)
            {
                main_textbox.AppendText("초회 한정 10뽑기 무료!" + "\r\n");
                //
                Random rand = new Random();
                main_textbox.AppendText(gachapool[0,0] + "\r\n");

                //gc = rand.Next(gachapool.Length-1);
                //main_textbox.AppendText(gachapool[g, g] + "\r\n");
                //gc = rand.Next(gachapool.Length-1);
                //main_textbox.AppendText(gachapool[g, g] + "\r\n");
                //gc = rand.Next(gachapool.Length-1);
                //main_textbox.AppendText(gachapool[g, g] + "\r\n");
                main_textbox.AppendText("이후부터는 10 골드로 10번 뽑기를 실행합니다." + "\r\n");
                main_textbox.ScrollToCaret();
            }
            else
            {
                savetxt[1] = (Convert.ToInt32(savetxt[1]) - 10).ToString();
                //
                Random rand = new Random();

            }

            StreamWriter save_ref = new StreamWriter("save.txt");
            for(int i = 0; i < savetxt.Count; i++)
            {
                save_ref.WriteLine(savetxt[i]);
            }
            save_ref.Close();
            savetxt.Clear();
            savetxt = File.ReadAllLines("save.txt").ToList();
        }

        private void main_statbt_Click(object sender, EventArgs e)
        {
            int index = savetxt.Count;
            main_textbox.AppendText("-------------------------" + "\r\n");
            main_textbox.AppendText("ID : " + savetxt[0] + "\r\n");
            main_textbox.AppendText("소지금 : " + savetxt[1] + "\r\n");

            main_textbox.AppendText("소지품 목록 : " + "\r\n");

            for (int i = 3; i < index; i++)
            {
                main_textbox.AppendText("ID : " + savetxt[i] + "\r\n");
            }
            main_textbox.AppendText("-------------------------" + "\r\n");
            main_textbox.ScrollToCaret();

        }

        private void main_startbt_Click(object sender, EventArgs e)
        {
            try
            {
                savetxt = File.ReadAllLines("save.txt").ToList();
                main_textbox.AppendText(savetxt[0] + "\r\n");
                main_textbox.AppendText("로그인 성공!" + "\r\n");
                main_textbox.ScrollToCaret();
            }
            catch
            {
                main_textbox.AppendText("세이브 데이터 없음" + "\r\n");
                main_textbox.AppendText("신규 ID 생성" + "\r\n");
                main_textbox.ScrollToCaret();
                StreamWriter save_new = new StreamWriter("save.txt");
                Random rand = new Random();
                int id = rand.Next(100000);
                main_textbox.AppendText("신규 ID : " + id.ToString("D6") + "\r\n");
                save_new.WriteLine(id.ToString("D6"));
                main_textbox.AppendText("신규 가입 보상 : 100 골드" +  "\r\n");
                save_new.WriteLine(100);
                save_new.Close();
                savetxt = File.ReadAllLines("save.txt").ToList();
            }
            finally
            {
                main_statbt.Enabled = true;
                main_gachabt.Enabled = true;
                main_startbt.Enabled = false;
            }
        }
    }
}
