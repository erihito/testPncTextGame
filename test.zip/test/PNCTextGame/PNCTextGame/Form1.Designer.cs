﻿
namespace PNCTextGame
{
    partial class wf_form01
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.wf_btn_up = new System.Windows.Forms.Button();
            this.wf_btn_down = new System.Windows.Forms.Button();
            this.wf_btn_left = new System.Windows.Forms.Button();
            this.wf_btn_right = new System.Windows.Forms.Button();
            this.wf_btn_yes = new System.Windows.Forms.Button();
            this.wf_btn_no = new System.Windows.Forms.Button();
            this.wf_textbox01 = new System.Windows.Forms.RichTextBox();
            this.wf_textbox02 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // wf_btn_up
            // 
            this.wf_btn_up.Location = new System.Drawing.Point(447, 314);
            this.wf_btn_up.Name = "wf_btn_up";
            this.wf_btn_up.Size = new System.Drawing.Size(50, 50);
            this.wf_btn_up.TabIndex = 0;
            this.wf_btn_up.Text = "button1";
            this.wf_btn_up.UseVisualStyleBackColor = true;
            this.wf_btn_up.Click += new System.EventHandler(this.wf_btn_up_Click);
            // 
            // wf_btn_down
            // 
            this.wf_btn_down.Location = new System.Drawing.Point(447, 404);
            this.wf_btn_down.Name = "wf_btn_down";
            this.wf_btn_down.Size = new System.Drawing.Size(50, 50);
            this.wf_btn_down.TabIndex = 1;
            this.wf_btn_down.Text = "button2";
            this.wf_btn_down.UseVisualStyleBackColor = true;
            this.wf_btn_down.Click += new System.EventHandler(this.wf_btn_down_Click);
            // 
            // wf_btn_left
            // 
            this.wf_btn_left.Location = new System.Drawing.Point(400, 359);
            this.wf_btn_left.Name = "wf_btn_left";
            this.wf_btn_left.Size = new System.Drawing.Size(50, 50);
            this.wf_btn_left.TabIndex = 2;
            this.wf_btn_left.Text = "button3";
            this.wf_btn_left.UseVisualStyleBackColor = true;
            this.wf_btn_left.Click += new System.EventHandler(this.wf_btn_left_Click);
            // 
            // wf_btn_right
            // 
            this.wf_btn_right.Location = new System.Drawing.Point(494, 359);
            this.wf_btn_right.Name = "wf_btn_right";
            this.wf_btn_right.Size = new System.Drawing.Size(50, 50);
            this.wf_btn_right.TabIndex = 3;
            this.wf_btn_right.Text = "button4";
            this.wf_btn_right.UseVisualStyleBackColor = true;
            this.wf_btn_right.Click += new System.EventHandler(this.wf_btn_right_Click);
            // 
            // wf_btn_yes
            // 
            this.wf_btn_yes.Location = new System.Drawing.Point(648, 359);
            this.wf_btn_yes.Name = "wf_btn_yes";
            this.wf_btn_yes.Size = new System.Drawing.Size(60, 60);
            this.wf_btn_yes.TabIndex = 4;
            this.wf_btn_yes.Text = "button5";
            this.wf_btn_yes.UseVisualStyleBackColor = true;
            this.wf_btn_yes.Click += new System.EventHandler(this.wf_btn_yes_Click);
            // 
            // wf_btn_no
            // 
            this.wf_btn_no.Location = new System.Drawing.Point(743, 359);
            this.wf_btn_no.Name = "wf_btn_no";
            this.wf_btn_no.Size = new System.Drawing.Size(60, 60);
            this.wf_btn_no.TabIndex = 5;
            this.wf_btn_no.Text = "button6";
            this.wf_btn_no.UseVisualStyleBackColor = true;
            this.wf_btn_no.Click += new System.EventHandler(this.wf_btn_no_Click);
            // 
            // wf_textbox01
            // 
            this.wf_textbox01.Location = new System.Drawing.Point(39, 31);
            this.wf_textbox01.Name = "wf_textbox01";
            this.wf_textbox01.ReadOnly = true;
            this.wf_textbox01.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.wf_textbox01.Size = new System.Drawing.Size(371, 273);
            this.wf_textbox01.TabIndex = 6;
            this.wf_textbox01.Text = "";
            // 
            // wf_textbox02
            // 
            this.wf_textbox02.Location = new System.Drawing.Point(507, 31);
            this.wf_textbox02.Name = "wf_textbox02";
            this.wf_textbox02.ReadOnly = true;
            this.wf_textbox02.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.wf_textbox02.Size = new System.Drawing.Size(224, 273);
            this.wf_textbox02.TabIndex = 7;
            this.wf_textbox02.Text = "";
            // 
            // wf_form01
            // 
            this.ClientSize = new System.Drawing.Size(836, 521);
            this.Controls.Add(this.wf_textbox02);
            this.Controls.Add(this.wf_textbox01);
            this.Controls.Add(this.wf_btn_no);
            this.Controls.Add(this.wf_btn_yes);
            this.Controls.Add(this.wf_btn_right);
            this.Controls.Add(this.wf_btn_left);
            this.Controls.Add(this.wf_btn_down);
            this.Controls.Add(this.wf_btn_up);
            this.Name = "wf_form01";
            this.ResumeLayout(false);

        }
        #endregion

        private System.Windows.Forms.Button wf_btn_up;
        private System.Windows.Forms.Button wf_btn_down;
        private System.Windows.Forms.Button wf_btn_left;
        private System.Windows.Forms.Button wf_btn_right;
        private System.Windows.Forms.Button wf_btn_yes;
        private System.Windows.Forms.Button wf_btn_no;
        private System.Windows.Forms.RichTextBox wf_textbox01;
        private System.Windows.Forms.RichTextBox wf_textbox02;
    }
}

