﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace PNCTextGame
{
    public partial class wf_form01 : Form
    {
        //상태체크
        Dictionary<string, bool> boolDic = new Dictionary<string, bool>
        {
            { "gameStart", false },
            { "dollSelect", false },
            { "battleStart", false }
        };
        //딕셔너리로부터 bool 출력
        public bool getBool(string key)
        {
            if (boolDic.TryGetValue(key, out bool value))
            {
                return value;
            }
            return false;
        }
        //딕셔너리로부터 bool 셋팅
        public void setBool(string key, bool value)
        {
            boolDic[key] = value;
        }
        //컨트롤 리스트 출력 파트
        List<string> list_control = new List<string>();
        int select_control = 0;
        int select_ok = -1;
        //인게임 텍스트 출력용 딕셔너리 선언
        Dictionary<string, string> strDic = new Dictionary<string, string>
        {
            { "titleCall", "-----텍스트 배틀 게임 타이틀-----" },
            { "gameExit", "-----게임을 종료합니다.-----"},
            { "selectChar", "-----캐릭터를 선택하세요.-----" },
            { "errorMsg", "An error has occurred. Please try again." },
        };
        Dictionary<string, List<string>> ctrlDic = new Dictionary<string, List<string>>
        {
            { "startMenu", new List<string> { "게임 시작", "게임 종료" } },
            { "dollSelect", new List<string> { "플레이어1", "플레이어2", "플레이어3", "플레이어4", "플레이어5" } }
        };
        //딕셔너리로부터 텍스트 출력 getStr(키워드) -> string
        public string getStr(string key)
        {
            if (strDic.TryGetValue(key, out string value))
            {
                return value;
            }
            return "텍스트를 찾을 수 없습니다.";
        }
        //딕셔너리로부터 리스트 출력 getList(키워드) -> list<string>
        public List<string> getList(string key)
        {
            if (ctrlDic.TryGetValue(key, out List<string> value))
            {
                return value;
            }
            return null;
        }

        // 윈폼 메인 함수 실행
        public wf_form01()
        {
            //컴포넌트 초기화
            InitializeComponent();
            wf_textbox01.AppendText("test before" + "\r\n");

            // KeyPreview 속성을 true로 설정
            this.KeyPreview = true;
            // KeyDown 이벤트 핸들러를 등록
            this.KeyDown += new KeyEventHandler(wf_form01_KeyDown);
            wf_textbox01.AppendText("test after" + "\r\n");

        }
        private void wf_form01_KeyDown(object sender, KeyEventArgs e)
        {
            // 특정 키가 눌렸을 때 버튼 클릭
            if (e.KeyCode == Keys.Up)  // 예: Enter 키가 눌렸을 때
            {
                wf_btn_up.PerformClick();
            }
            if (e.KeyCode == Keys.Down)  // 예: Enter 키가 눌렸을 때
            {
                wf_btn_down.PerformClick();
            }
            if (e.KeyCode == Keys.Left)  // 예: Enter 키가 눌렸을 때
            {
                wf_btn_left.PerformClick();
            }
            if (e.KeyCode == Keys.Right)  // 예: Enter 키가 눌렸을 때
            {
                wf_btn_right.PerformClick();
            }
            if (e.KeyCode == Keys.Z)  // 예: Enter 키가 눌렸을 때
            {
                wf_btn_yes.PerformClick();
            }
            if (e.KeyCode == Keys.X)  // 예: Enter 키가 눌렸을 때
            {
                wf_btn_no.PerformClick();
            }
        }

        private void wf_btn_up_Click(object sender, EventArgs e)
        {
            wf_textbox01.AppendText("up" + "\r\n");
        }

        private void wf_btn_down_Click(object sender, EventArgs e)
        {
            wf_textbox01.AppendText("down" + "\r\n");

        }

        private void wf_btn_left_Click(object sender, EventArgs e)
        {
            wf_textbox01.AppendText("left" + "\r\n");

        }

        private void wf_btn_right_Click(object sender, EventArgs e)
        {
            wf_textbox01.AppendText("right" + "\r\n");

        }

        private void wf_btn_yes_Click(object sender, EventArgs e)
        {
            wf_textbox01.AppendText("yes" + "\r\n");

        }

        private void wf_btn_no_Click(object sender, EventArgs e)
        {
            wf_textbox01.AppendText("no" + "\r\n");

        }
    }
}
