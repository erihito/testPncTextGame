﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace imwp
{ 
    public partial class form_main : Form
    {
        string textmsg;

        bool start_check = false;

        public form_main()
        {
            InitializeComponent();
        }
        protected void form_main_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.D1:
                    main_textbox.AppendText("key : " + 1 + "\r\n");
                    break;
            }
            if (e != null)
            {
                main_textbox.AppendText(e.KeyCode + "\r\n");
                main_textbox.ScrollToCaret();
            }
            if (e.KeyCode == Keys.Enter)
            {
                if (main_textin.Enabled == false)
                {
                    main_textin.Enabled = true;
                    main_textin.Focus();
                }
                else if (main_textin.Enabled == true && main_textin.Text.Length != 0)
                {
                    textmsg = main_textin.Text.ToString();
                    main_textbox.AppendText(textmsg + "\r\n");
                    main_textbox.ScrollToCaret();

                    //input function
                    command_fnc(textmsg);

                    main_textin.Enabled = false;
                    main_textin.Clear();
                }
                else if (main_textin.Enabled == true && main_textin.Text.Length == 0)
                {
                    main_textin.Enabled = false;
                    //main_textbox.AppendText("-" + "\r\n");
                    //main_textbox.ScrollToCaret();
                }
            }
        }

        public void command_fnc(string text)
        {
            string[] command = text.Split(' ');
            if (command[0] == "do")
            {
                //foreach (string s in command)
                //{
                //    main_textbox.AppendText(s+"\r\n");
                //}
                try
                {
                    switch (command[1])
                    {
                        case "start":
                            start_check = true;
                            gamemain_fnc();
                            main_textbox.AppendText("-START!" + "\r\n");
                            main_textbox.ScrollToCaret();
                            break;
                        case "list":
                            main_textbox.AppendText("-test : print TEST!" + "\r\n");
                            main_textbox.AppendText("-list : print command list" + "\r\n");
                            main_textbox.AppendText("-clear : clear txt box" + "\r\n");
                            main_textbox.AppendText("-exit : program exit" + "\r\n");
                            main_textbox.ScrollToCaret();
                            break;
                        case "test":
                            main_textbox.AppendText("-TEST!" + "\r\n");
                            main_textbox.ScrollToCaret();
                            break;
                        case "clear":
                            main_textbox.Clear();
                            break;
                        case "echo":
                            main_textbox.AppendText("-ECHO : ");
                            for(int i = 2; i < command.Length; i++)
                            {
                                main_textbox.AppendText(command[i]+ " ");
                            }
                            main_textbox.AppendText("\r\n");
                            main_textbox.ScrollToCaret();
                            break;
                        case "exit":
                            Application.Exit();
                            break;
                        default:
                            main_textbox.AppendText("-Invalid command" + "\r\n");
                            main_textbox.ScrollToCaret();
                            break;

                    }
                }
                catch
                {
                    main_textbox.AppendText("-Use \"do (command)\"" + "\r\n");
                    main_textbox.ScrollToCaret();
                }
            }
        }

        public void gamemain_fnc()
        {
            
        }
    }
}
