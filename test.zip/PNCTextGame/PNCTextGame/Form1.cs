﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace PNCTextGame
{
    public partial class wf_form01 : Form
    {
        //선택 변수
        int select_ok = -1;
        Dictionary<string, bool> boolDic = new Dictionary<string, bool>
        {
            { "gameStart", false },
            { "dollSelect", false },
            { "battleStart", false }
        };
        //딕셔너리로부터 bool 출력
        public bool getBool(string key)
        {
            if (boolDic.TryGetValue(key, out bool value))
            {
                return value;
            }
            return false;
        }
        //딕셔너리로부터 bool 셋팅
        public void setBool(string key, bool value)
        {
            boolDic[key] = value;
        }
        //컨트롤 리스트 출력 파트
        List<string> list_control = new List<string>();
        bool check_control = false;
        int select_control = 0;
        //인게임 텍스트 출력용 딕셔너리 선언
        Dictionary<string, string> strDic = new Dictionary<string, string>
        {
            { "titleCall", "-----텍스트 배틀 게임 타이틀-----" },
            { "gameExit", "-----게임을 종료합니다.-----"},
            { "selectChar", "-----캐릭터를 선택하세요.-----" },
            { "errorMsg", "An error has occurred. Please try again." },
        };
        Dictionary<string, List<string>> ctrlDic = new Dictionary<string, List<string>>
        {
            { "startMenu", new List<string> { "게임 시작", "게임 종료" } },
            { "dollSelect", new List<string> { "플레이어1", "플레이어2", "플레이어3", "플레이어4", "플레이어5" } }
        };
        //딕셔너리로부터 텍스트 출력 getStr(키워드) -> string
        public string getStr(string key)
        {
            if (strDic.TryGetValue(key, out string value))
            {
                return value;
            }
            return "텍스트를 찾을 수 없습니다.";
        }
        //딕셔너리로부터 리스트 출력 getList(키워드) -> list<string>
        public List<string> getList(string key)
        {
            if (ctrlDic.TryGetValue(key, out List<string> value))
            {
                return value;
            }
            return null;
        }

        // 윈폼 메인 함수 실행
        public wf_form01()
        {
            //컴포넌트 초기화
            InitializeComponent();
            
            //게임 타이틀 출력
            wf_textbox01.AppendText(getStr("titleCall"));
            //게임 시작
            gameStart();
        }
        //게임 시작하기 위한 메뉴 출력
        private void gameStart()
        {
            //리스트 스타트 메뉴로 초기화
            list_control = new List<string>(getList("startMenu"));
            //체크 컨트롤 true로 조작 on
            check_control = true;
            select_ok = -1;
            //
            displayControlPannel(list_control);
            setBool("gameStart", true);

        }
        private void dollSelect()
        {
            displayControlPannel(list_control);

            wf_textbox01.AppendText("\r\n" + "test");
        }
        //키보드 입력 처리 파트
        private void wf_form01_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e != null)
            {
                //wf_textbox01.AppendText("\r\n" + "code : " + e.KeyCode);
                //wf_textbox01.AppendText("\r\n" + "value : " + e.KeyValue);
            }
            if ((char)e.KeyCode == 'Z')
            {
                wf_textbox01.AppendText("\r\n" + "key : " + "Z");
                if (check_control == true)
                {
                    select_ok = select_control;
                    wf_textbox01.AppendText("\r\n" + "select control : " + select_control);
                    wf_textbox01.AppendText("\r\n" + "select ok : " + select_ok);
                    if (getBool("gameStart"))
                    {
                        setBool("gameStart", false);
                        list_control = new List<string>(getList("dollSelect"));
                        dollSelect();

                    }
                    else if (getBool("dollSelect"))
                    { 
                    }
                }
            }
            if ((char)e.KeyCode == 'X')
            {
                wf_textbox01.AppendText("\r\n" + "key : " + "X");
            }
            if (e.KeyValue == 38)
            {
                wf_textbox01.AppendText("\r\n" + "key : " + "Up");
                if (check_control == true)
                {
                    select_control--;
                    wf_textbox01.AppendText("\r\n" + "select : " + select_control);
                    displayControlPannel(list_control);
                }
            }
            if (e.KeyValue == 40)
            {
                wf_textbox01.AppendText("\r\n" + "key : " + "Down");
                if (check_control == true)
                {
                    select_control++;
                    wf_textbox01.AppendText("\r\n" + "select : " + select_control);
                    displayControlPannel(list_control);
                }
            }
            wf_textbox01.ScrollToCaret();

        }
        private void displayControlPannel(List<string> listcontrol)
        {
            //컨트롤 패널 초기화
            wf_textbox02.Clear();
            List<string> listcontrol_rep = new List<string>(listcontrol);

            select_control = select_control % listcontrol_rep.Count;
            if (select_control < 0)
            {
                select_control = select_control + listcontrol_rep.Count;
            }
            //컨트롤 패널 출력
            if (0 <= select_control && select_control < listcontrol_rep.Count)
            {
                listcontrol_rep[select_control] += " ◀";
            }
            foreach (string control in listcontrol_rep)
            {
                wf_textbox02.AppendText(control + Environment.NewLine);
            }
        }
        //각종 함수 테스트용
        private void wf_testbutton01_Click(object sender, EventArgs e)
        {
            list_control = new List<string> { "선택지1", "선택지2", "선택지3", "선택지4" };
            check_control = true;
            select_control = 0;
            wf_textbox01.AppendText("\r\n" + "check&select : " + check_control + " " + select_control);
            displayControlPannel(list_control);
        }
    }
}
