﻿
namespace PNCTextGame
{
    partial class wf_form01
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.wf_textbox01 = new System.Windows.Forms.RichTextBox();
            this.wf_group01 = new System.Windows.Forms.GroupBox();
            this.wf_group02 = new System.Windows.Forms.GroupBox();
            this.wf_textbox02 = new System.Windows.Forms.RichTextBox();
            this.wf_testbutton01 = new System.Windows.Forms.Button();
            this.wf_group01.SuspendLayout();
            this.wf_group02.SuspendLayout();
            this.SuspendLayout();
            // 
            // wf_textbox01
            // 
            this.wf_textbox01.Location = new System.Drawing.Point(20, 20);
            this.wf_textbox01.Name = "wf_textbox01";
            this.wf_textbox01.ReadOnly = true;
            this.wf_textbox01.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.wf_textbox01.Size = new System.Drawing.Size(322, 287);
            this.wf_textbox01.TabIndex = 0;
            this.wf_textbox01.TabStop = false;
            this.wf_textbox01.Text = "";
            this.wf_textbox01.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.wf_form01_PreviewKeyDown);
            // 
            // wf_group01
            // 
            this.wf_group01.Controls.Add(this.wf_textbox01);
            this.wf_group01.Location = new System.Drawing.Point(12, 261);
            this.wf_group01.Name = "wf_group01";
            this.wf_group01.Size = new System.Drawing.Size(361, 325);
            this.wf_group01.TabIndex = 1;
            this.wf_group01.TabStop = false;
            this.wf_group01.Text = "전투 로그";
            // 
            // wf_group02
            // 
            this.wf_group02.Controls.Add(this.wf_textbox02);
            this.wf_group02.Location = new System.Drawing.Point(396, 261);
            this.wf_group02.Name = "wf_group02";
            this.wf_group02.Size = new System.Drawing.Size(197, 325);
            this.wf_group02.TabIndex = 2;
            this.wf_group02.TabStop = false;
            this.wf_group02.Text = "컨트롤 패널";
            // 
            // wf_textbox02
            // 
            this.wf_textbox02.Location = new System.Drawing.Point(15, 20);
            this.wf_textbox02.Name = "wf_textbox02";
            this.wf_textbox02.ReadOnly = true;
            this.wf_textbox02.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.wf_textbox02.Size = new System.Drawing.Size(163, 287);
            this.wf_textbox02.TabIndex = 0;
            this.wf_textbox02.TabStop = false;
            this.wf_textbox02.Text = "";
            this.wf_textbox02.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.wf_form01_PreviewKeyDown);
            // 
            // wf_testbutton01
            // 
            this.wf_testbutton01.Location = new System.Drawing.Point(488, 213);
            this.wf_testbutton01.Name = "wf_testbutton01";
            this.wf_testbutton01.Size = new System.Drawing.Size(105, 42);
            this.wf_testbutton01.TabIndex = 3;
            this.wf_testbutton01.TabStop = false;
            this.wf_testbutton01.Text = "Test";
            this.wf_testbutton01.UseVisualStyleBackColor = true;
            this.wf_testbutton01.Click += new System.EventHandler(this.wf_testbutton01_Click);
            this.wf_testbutton01.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.wf_form01_PreviewKeyDown);
            // 
            // wf_form01
            // 
            this.ClientSize = new System.Drawing.Size(605, 598);
            this.Controls.Add(this.wf_testbutton01);
            this.Controls.Add(this.wf_group02);
            this.Controls.Add(this.wf_group01);
            this.Name = "wf_form01";
            this.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.wf_form01_PreviewKeyDown);
            this.wf_group01.ResumeLayout(false);
            this.wf_group02.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox wf_textbox;
        private System.Windows.Forms.RichTextBox wf_textbox01;
        private System.Windows.Forms.GroupBox wf_group01;
        private System.Windows.Forms.GroupBox wf_group02;
        private System.Windows.Forms.RichTextBox wf_textbox02;
        private System.Windows.Forms.Button wf_testbutton01;
    }
}

